// defines functions as all documents load.
 

